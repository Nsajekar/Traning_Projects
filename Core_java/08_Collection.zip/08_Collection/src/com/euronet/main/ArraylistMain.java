package com.euronet.main;

import java.util.List;
import java.util.ArrayList;

public class ArraylistMain {

	public static void main(String[] args) {
		List<Integer> numberList = new ArrayList<>();
		numberList.add(101);
		numberList.add(102);
		numberList.add(103);
		numberList.add(104);
		numberList.add(104);
		System.out.println(numberList);

	}

}
