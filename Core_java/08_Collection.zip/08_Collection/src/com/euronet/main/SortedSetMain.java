package com.euronet.main;

import java.util.Set;
import java.util.TreeSet;

public class SortedSetMain {
	public static void main(String[] args) {
		Set<String> nameSet = new TreeSet<>();
		nameSet.add("Mayur");
		nameSet.add("Mandar");
		nameSet.add("Nitesh");
		nameSet.add("ibrahim");
		nameSet.add("Pranali");
		nameSet.add("Pravin");
		System.out.println(nameSet);
	}
}
